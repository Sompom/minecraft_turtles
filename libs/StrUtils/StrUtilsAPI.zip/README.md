String Utils API implemented in Lua.

Latest Functions:
CRC32(str) --Returns CRC32 Hash of @str
FCS16(str) --Returns FCS16 Hash of @str
FCS32(str) --Returns FCS32 Hash of @str
replace(str, from, to)  --Replaces @from to @to in @str